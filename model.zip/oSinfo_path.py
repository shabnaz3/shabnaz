import os_info
import platform
import socket
from datetime import date
import webbrowser
import httpx
import urllib
from oSinfo_Model import Intro

url='http://www.geoplugin.net/json.gp?ip=185.66.194.78'
params = {'ip': '185.66.194.78', }      # parameter and keyword
r1 = httpx.get('http://www.geoplugin.net/json.gp', params=params)
response=httpx.get(url,params=params)

intro=Intro(os=f"{platform.system()}",
                 version=f"{platform.release()}",
                 processor=f"{platform.processor()}",
                 hostname=f"{socket.gethostname()}",
                 ip=f"{socket.gethostbyname(socket.gethostname())}",
                 today=f"{date.today()}",
                 #location="http://www.geoplugin.net/json.gp?ip=185.66.194.78",
                 location= r1.json()['geoplugin_request'], # oi link ei information ta shudhu nibo
                 city=r1.json()['geoplugin_city'], # privious
                 state = r1. json() ['geoplugin_regionName'])