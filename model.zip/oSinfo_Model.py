#import platform
#import socket
#from datetime import date
#import webbrowser
#import httpx
#import urllib

from pydantic import BaseModel

class Intro(BaseModel):
    os:str
    version:str
    processor:str
    hostname:str
    ip:str
    today:str
    location:str
    city:str
    state:str




