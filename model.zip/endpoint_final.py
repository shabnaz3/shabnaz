import dic_config
import model
from model import  Selfdescription
from dic_config import Configuration
from oSinfo_Model import Intro
from fastapi import FastAPI

title=model.Title(value="b",language="c")
#Catalog( define offer,Protocol)
#In offer define description, keyword,resourceEndpoint,standardLicence

description=model.Description(value="e",language="f")
keyword=model.Keyword(value="g",language="h")
#In ResourceEndpoint define endpointHost
#In endpointHost define Protocol
endpointHost=model.EndpointHost(type="j",id="k",protocol=model.Protocol(id="i"),accessUrl="l")

resourceEndpoint=model.ResourceEndpoint(type="m",id="n",path="o",endpointArtifact=None,endpointHost=endpointHost,)

offer=model.Offer(type="p",id="q",version="r",title=[title],description=[description],customLicense="s",keyword=[keyword],
                  resourceEndpoint=[resourceEndpoint],standardLicense=model.StandardLicense(id="t"))
protocol=model.Protocol(id="v")
catalog=model.Catalog(type="u",offer=[offer],id="u",title=title,protocol=[protocol])

#Selfdescription

self=model.Selfdescription(type="v",title=[title],context="w",catalog=catalog,outboundModelVersion="x",
                                      inboundModelVersion=["a","b"],curator=Configuration["curator"],
                                     maintainer=Configuration ["maintainer"],id="end")


#  for Osinfo

from oSinfo_path import intro
app = FastAPI()

@app.get("/idsa_infomodel/", response_model=Selfdescription)

async def read_item():
    return self

@app.get("/os_info/",response_model=Intro)
async def read_item():
    return intro
