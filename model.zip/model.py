from pydantic import BaseModel
from typing import Optional, List


class Title(BaseModel):
    value: str
    language: str


class EndpointArtifact(BaseModel):
    type: str
    id: str
    fileName: str
    byteSize: str
    checkSum: str


class Protocol(BaseModel):
    id: str


class EndpointHost(BaseModel):
    type: str
    id: str
    protocol: Protocol
    accessUrl: str


class ResourceEndpoint(BaseModel):
    type: str
    id: str
    path: str
    endpointArtifact: Optional[EndpointArtifact] = None
    endpointHost: EndpointHost


class StandardLicense(BaseModel):
    id: str


class Keyword(BaseModel):
    value: str
    language: str


class Description(BaseModel):
    value: str
    language: str


class Offer(BaseModel):
    type: str
    id: str
    version: str
    title: List[Title]
    description: List[Description]
    customLicense: str
    keyword: List[Keyword]
    resourceEndpoint: List[ResourceEndpoint]
    standardLicense: StandardLicense


class Catalog(BaseModel):
    type: str
    offer: List[Offer]
    id: str
    title:Title
    protocol:list[Protocol]
class Selfdescription(BaseModel):
    type: str
    title: List[Title]
    context: str
    catalog: Catalog
    outboundModelVersion: str
    inboundModelVersion: List[str]
    curator: str
    maintainer: str
    id: str

